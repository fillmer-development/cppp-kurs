#include <iostream>
int main()
{
    std::cout << "Hello, Malte!\n";
    return 0;
}